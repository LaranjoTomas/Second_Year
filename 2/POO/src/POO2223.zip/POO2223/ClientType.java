
public enum ClientType {
    ENTERPRISE, PERSONAL;
}
